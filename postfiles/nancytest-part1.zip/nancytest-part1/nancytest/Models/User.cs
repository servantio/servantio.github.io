﻿namespace nancytest.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}